using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class dash : MonoBehaviour
{
    public Vector3 TeleportAreaCenter;
    public Vector3 TeleportAreaSize;
    public Transform pc;
    public skills_manager.skill skill_op;
    public stats.stat stat;
    public int dash_type;   
    public LayerMask obstacleLayer;
    private monster monster;
    // Start is called before the first frame update
    void Start()
    {
        if(dash_type == 0) Destroy(this,skill_op.life_time);
        if(gameObject.tag == "Player"){
            player pc = gameObject.GetComponent<player>();
            stat = pc.player_stat;
            if(stat.move_D == Vector3.zero){
                stat.move_D = pc.get_mouse_pos() - transform.position;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(dash_type == 0) dsah();
        else if(dash_type == 1) Teleport();
    }
    public void dsah(){
        transform.Translate(stat.move_D * skill_op.speed * Time.deltaTime, Space.World);
    }

    public void Teleport()
    {
        Vector3 newPosition = GetTeleportPosition();
        if (newPosition != Vector3.zero)
        {
            transform.position = newPosition;
        }
    }

    private Vector3 GetTeleportPosition()
    {
        float currentDistanceToPc = Vector3.Distance(transform.position, pc.position);

        for (int i = 0; i < 10; i++)
        {
            Vector3 randomPosition = GetRandomPositionInArea();
            if (IsValidTeleportPosition(randomPosition) && Vector3.Distance(randomPosition, pc.position) > currentDistanceToPc)
            {
                return randomPosition;
            }
        }

        return Vector3.zero;
    }

    private Vector3 GetRandomPositionInArea()
    {
        float x = Random.Range(-TeleportAreaSize.x / 2, TeleportAreaSize.x / 2);
        float y = Random.Range(-TeleportAreaSize.y / 2, TeleportAreaSize.y / 2);
        float z = Random.Range(-TeleportAreaSize.z / 2, TeleportAreaSize.z / 2);

        return TeleportAreaCenter + new Vector3(x, y, z);
    }

    private bool IsValidTeleportPosition(Vector3 position)
    {
        if (Physics.CheckSphere(position, 1f, obstacleLayer))
        {
            return false;
        }

        return true;
    }
}
