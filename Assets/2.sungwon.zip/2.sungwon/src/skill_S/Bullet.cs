using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.InputSystem;
// using System.Diagnostics;

public class bullet : MonoBehaviour
{   
    public skills_manager.skill skill_op;
    void Start()
    {   

    }
    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.forward * skill_op.speed * Time.deltaTime);
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag != skill_op.sp_pos.tag)
        {   
            Destroy(gameObject);
        }
    }
}
