using System.Collections;
using System.Collections.Generic;
using System.Linq.Expressions;
using UnityEngine;

public class player_now_state : MonoBehaviour
{

    
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }


}
