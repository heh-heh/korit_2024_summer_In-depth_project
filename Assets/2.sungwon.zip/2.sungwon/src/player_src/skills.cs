using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Tracing;

// using System.Numerics;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEditor;
using UnityEditor.Rendering;
using UnityEditor.Search;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Interactions;

public class skills : MonoBehaviour
{
    public stats.stat player_stat;
    public skills_manager sk_manager;
    public int attect_combo = 0;
    public bool is_delay;
    bool is_attect;
    public float co_time;
    public float attect_delay;
    Animator animator;
    player pc;
    public List<string> skill_ID = new List<string>();


    
    // Start is called before the first frame update
    void Start()
    {
        pc = GetComponent<player>();
        
        animator = GetComponent<Animator>();
        co_time = attect_delay;
        
    }
    void Update()
    {
        player_stat = pc.player_stat;
    }

    
    public void on_attack(InputAction.CallbackContext context){
        // animator.SetTrigger("attect");
        if(context.performed && !player_stat.is_skill){
            
            // animator.SetBool("m_at",true);
            // animator.SetTrigger("test");
            // if(!is_attect && attect_combo>0) attect_combo = 0;
            // if(context.interaction is PressInteraction){
            //     attect_combo ++;
            //     animator.SetFloat("attect_combo",attect_combo);
            //     if(attect_combo <= 0){
            //         co_time = attect_delay;
            //         StartCoroutine(use_Skills_delay(skill_ID[attect_combo]));
            //     }
            //     else if(is_attect){
            //         co_time = attect_delay;
            //         StartCoroutine(use_Skills_delay(skill_ID[attect_combo]));
            //         if(sk_manager.skill_dict[skill_ID[attect_combo]].next_at_ID == "") attect_combo = 0;
            //     }
            //     StartCoroutine(attect_ck());
            //     // if(!is_attect && attect_combo>0) attect_combo = 0;
            // }
            if(context.interaction is PressInteraction){
                if(attect_combo <= 0){
                    player_stat.move_D = pc.get_mouse_pos()-transform.position;
                    transform.LookAt(pc.get_mouse_pos());
                    StartCoroutine(use_Skills_delay(skill_ID[0]));
                }
            }
        }
    }
    public void use_skiil(InputAction.CallbackContext context){
        
    }

    
    public IEnumerator use_Skills_delay(string ID){
        pc.player_stat.is_skill = true;
        Debug.Log("ID : " + ID);
        if(sk_manager.skill_dict[ID].before_delay > 0){
            for(float i = sk_manager.skill_dict[ID].before_delay; i>0 ;i-=0.01f)
                yield return new WaitForSeconds(0.01f);
        } 
        sk_manager.use_skill(ID,gameObject);

        if(sk_manager.skill_dict[ID].after_delay > 0){
            for(float i = sk_manager.skill_dict[ID].after_delay; i>0 ;i-=0.01f)
                yield return new WaitForSeconds(0.01f);
        }
        
        
        pc.player_stat.is_skill = false;

    }
    public IEnumerator attect_ck(){
        is_attect = true;
        for(; co_time>0 ;co_time-=Time.deltaTime){
            yield return new WaitForSeconds(Time.deltaTime);
        }
        is_attect = false;
    }
}
