using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;

public class monster : gamemanager
{
    public GameObject target;
    public float speed = 5f;
    public float range = 10f;
    public float hit_time = 1;
    public bool hit_ck = false;
    public float demege;

    bool die = false;

    public float [] hp = new float[2];
    
    void Start(){

    }
    private void hit()
    {
        Debug.Log("hitted");
    }
    void Update()
    {
        float distance = Vector3.Distance(transform.position, target.transform.position);
        if (distance <= range)
        {
            transform.LookAt(target.transform);

            transform.position = Vector3.MoveTowards(transform.position, target.transform.position, speed * Time.deltaTime);
        }
        if(hp[0]+hp[1] <=0) die=true;
        if(die) Destroy(this);
    }

    private void OnCollisionStay(Collision other)
    {
        if (other.gameObject.tag == "Player")
        {
            if(!hit_ck){
                hit_ck = true;
                // player_now_state pns = other.gameObject.GetComponent<player_now_state>();
                // pns.now_hp -= demege;
                StartCoroutine(cooldowon(hit_time));
            }
        }
    }
    private void OnTriggerEnter(Collider other) {
        if(other){
            switch(other.gameObject.tag){
                case "sword":
                    // if(skills.skills_cooldowon["m_at"]){
                    //     Debug.Log("sword_demege");
                    // }
                    // if(skills.skills_cooldowon["Sword_aura"]){
                    //     Debug.Log("Sword_aura_demege");
                    // }
                break;
            }
        }
    }

    public void on_Demege(float demege, int wapon_type, int hp_type){
        if (hp_type != wapon_type){
            hp[hp_type-1] -= demege * 0.1f;
        }
        else{
            hp[hp_type-1] = hp[hp_type-1] - demege;
        }
    }

    IEnumerator cooldowon(float time){
        for(float i = time; i>0 ;i-=0.1f){
            yield return new WaitForSeconds(0.1f);
        }
        hit_ck=false;
    }
}